#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "sleep.h"

XGpio leds;
XGpio switches;
XGpio buttons;
XGpio seg_disp;
XGpio seg_an;

int message_in_hex[12] = {0xff, 0x89, 0x86, 0xc7, 0xc7, 0xc0, 0xff, 0xa4, 0xc0, 0xa4, 0x92, 0xff};

void initGPIO(){
	XGpio_Initialize(&leds,XPAR_AXI_GPIO_0_DEVICE_ID);
	XGpio_SetDataDirection(&leds, 1, 0x0000);
	XGpio_Initialize(&switches,XPAR_AXI_GPIO_0_DEVICE_ID);
	XGpio_SetDataDirection(&switches, 2, 0xffff);
	XGpio_Initialize(&buttons,XPAR_AXI_GPIO_1_DEVICE_ID);
	XGpio_SetDataDirection(&buttons, 1, 0xffff);
	XGpio_Initialize(&seg_disp,XPAR_AXI_GPIO_1_DEVICE_ID);
	XGpio_SetDataDirection(&seg_disp, 2, 0x0000);
	XGpio_Initialize(&seg_an,XPAR_AXI_GPIO_2_DEVICE_ID);
	XGpio_SetDataDirection(&seg_an, 1, 0x0000);

}

void hello2seg(){
	for (int i = 0; i < 10; i++){
		for (int _ = 0; _ < 50 ; _++){
			for (int j = 0; j < 4; j++){
				XGpio_DiscreteWrite(&seg_an, 1, 0xffff - (1<<(3-j)));
				XGpio_DiscreteWrite(&seg_disp, 2,message_in_hex[i+j]);
				usleep(1000);
			}
		}
	}
}

void afficher_hello(int position){
	for (int j = 0; j < 4; j++){
		XGpio_DiscreteWrite(&seg_an, 1, 0xffff - (1<<(3-j)));
		XGpio_DiscreteWrite(&seg_disp, 2,message_in_hex[(position+j)%12]);
		usleep(5000);
	}
}

void animer_message(int sens){
	while(1){

		for (int i = 0; i < 9; i++){
			int position = (sens==0)?i:8-i;
				for (int _ = 0; _ < 50 ; _++){
					afficher_hello(position);
				}
		}
	}
}

void infinite_animer_message(int sens){
	int i = 0;
	while(1){
		int position = (sens==0)?i:12-i;
		for (int _ = 0; _ < 40 ; _++){
			afficher_hello(position);
		}
		i++;
		i %= 12;
	}
}



int main()
{
	init_platform();

	    initGPIO();
	    int direction = 0;
	    // classic version
	    //animer_message(direction);

	    // infinite version
	    infinite_animer_message(direction);



	    cleanup_platform();
	    return 0;
}
